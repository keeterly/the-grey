
# The Grey — Hand Drag & Hold-to-Preview

Adds:
- `src/ui/hand-dnd.js` — pointer-based drag with ghost, slot highlight, and press/hold preview
- `src/styles/hand-dnd.css` — overlay, instant pulse, and visual polish

The apply script wires CSS + module into `index.html`. Tweak selectors in the module init if your DOM differs.
