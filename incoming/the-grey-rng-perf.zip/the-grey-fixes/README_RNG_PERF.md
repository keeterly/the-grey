
Seeded RNG + Animation Perf Pack
- src/lib/seeded-rng.js (mulberry32 createRNG/createUID)
- src/styles/perf.css (.anim-layer for GPU-friendly transforms)
- src/ui/anim-helpers.js (animateFly)

Optional global determinism:
  <script>window.__THE_GREY_SEED = 12345;</script>
