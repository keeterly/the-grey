# The Grey — Hand DnD v3

Includes files + helper that patches index.html and copies assets.
