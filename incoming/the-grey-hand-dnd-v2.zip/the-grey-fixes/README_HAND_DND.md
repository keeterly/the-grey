
# The Grey — Hand Drag & Hold-to-Preview (v2, auto-detect)
- Automatically finds your hand strip (bottom scrollable with portrait cards) if no explicit selector.
- Adds hold-to-preview, smooth drag ghost, slot hover highlight.
- No engine hookups changed.

The apply script wires CSS and a `<script type="module" src="src/ui/hand-dnd.js">` tag into `index.html`.
